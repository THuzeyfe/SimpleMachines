from .leverClass import lever
from .pulleyClass import pulley